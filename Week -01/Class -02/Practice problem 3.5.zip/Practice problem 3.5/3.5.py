S="Abdullah"
s="Mamun"
res=S[-9:-6]
res1=s[-5:-2]
print(res+res1)