S="Abdullah Al Mamun"
res=S[-17:-9]
print(res)
res1=S[-5:]
res3=res,res1
print(res3)