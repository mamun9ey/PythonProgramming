s="Shikkhangon BD"
res=s[12:15]
print(res)
res1=s[5:8]
print(res1)