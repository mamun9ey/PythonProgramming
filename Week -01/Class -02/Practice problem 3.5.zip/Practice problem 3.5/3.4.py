S="Abdullah"
s="Mamun"
res=S[0:2]
res1=s[0:3]
print(res+res1)