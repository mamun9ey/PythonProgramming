S="Code With Redoy"
a=S[5:9]
b=S[10:15]
print(a+b)
