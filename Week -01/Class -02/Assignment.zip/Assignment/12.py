#12)Write a program to perfrom addition,subtraction,multiplication and division of two number 
a = 8
b = 7
add=a+b
print(add)
sub= a-b
print(sub)
mul=a*b
print(mul)
div=a/b
print(div)
