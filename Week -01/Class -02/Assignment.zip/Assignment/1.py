#Sammi and Sumiya are two best friends Sammin guesses a non-negative floating point number that devisable by 2.Now set this number in a variable and convert it to a string.Now Sumiya guesses this same number and converts it into an integer making it double.Print the result 
x=26.4
print(x)
print(str(x))
print(int(x))