#4)Chef and Chefina are taking about the perimeter of a rectangle.Chef asks Chefina id I provide the length and breadth of a rectangle,can you find the perimeter of that rectangle ?So now your job is to make a program that can find out the perimeter of any rectangle where length and breadth should be taken from the user 
a = input("Enter length:")
print("length is: " + a)
b = input("Enter breadth:")
print("breadth is: " + b)   
Perimeter = 2*(a+ b)  
print("Perimeter of rectangle is: ");  
print(Perimeter);   