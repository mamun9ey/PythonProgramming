#Chef and chefina are a very romantic couple.Today they will play a game.The game is very simple.The first chef will tell a number to chefina that will be stored in a double quotation.The job of Chefina is to double that number and that will be divisible by 2 .Then subtract any number from chefina's number that will be greter than ().print the number 
x="25"
x1=50
res1=x1-60
print(res1)
