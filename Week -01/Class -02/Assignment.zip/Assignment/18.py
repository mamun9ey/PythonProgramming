#write a program to enter any number and calculate its square root
import math

# Return the square root of different numbers
print (math.sqrt(9))
print (math.sqrt(25))
print (math.sqrt(16))