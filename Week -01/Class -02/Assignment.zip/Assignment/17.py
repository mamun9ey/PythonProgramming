#Write a program to find power of any number x^y 
x,y=4,3
print(pow(x, y))