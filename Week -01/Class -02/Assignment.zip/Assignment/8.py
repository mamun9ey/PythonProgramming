#8)write a program to calculate area of an equilateral triangle
a= 5  
area = ( 1.73 * a*a) / 4  
print("Area of Equilateral Triangle is: ");  
print(area); 