#20)Write a program to calculate a bike's average consumption from the given total distance traveled and spent fuel .
print("Input total distance in km: ")
x=int(input())
print("Input total fuel spent in liters: ")
y=float(input())
print("Average consumption (km/lt)",x/y)