#Write a program to find power of any number x^y (using pow ()function)
x,y=4,3
print(pow(x, y))