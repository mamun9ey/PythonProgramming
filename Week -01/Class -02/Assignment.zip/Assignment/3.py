#Sammi and Sumiya are two best friends Sammin guesses a number that is notdevisable by 2 and sumiya guesses the opposite.Suddenly Sumiya got angry with Sammi .So she wants to divided Sammi's nmuber by her number .Now find out the result respectively int type,float type and string type
x=7
x1=12
res1=x/x1
print(int(res1))
print(float(res1))
print(str(res1))
