#14)write a program that takes minutes as input and display the total number of hours and minutes
minutes =120
hours = minutes/60
print(hours, minutes)