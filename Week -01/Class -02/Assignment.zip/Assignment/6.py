#6)Write a program to enter length and breadth of a rectangle and find it's perimeter.
a=c=2 # in rectangle sides opposite to each other are equal in length  
b=d=4 # length of opposite sides  
Perimeter = 2*(a+ b)  
print("Perimeter of rectangle is: ");  
print(Perimeter)