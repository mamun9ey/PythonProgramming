#7)Write a program to enter length and breadth of a rectangle and find it's area.
print("Enter Length of Rectangle: ")
l = float(input())
print("Enter Breadth of Rectangle: ")
b = float(input())
a = l*b
print("\nArea = ", a)