#5)Can you make a program for me that can convert the temperature Fahrenheit to Centigrade and Centigrade to Fahrenheit
#input celcius
celsius = 27

#calculate fahrenheit using the formula
fahrenheit = (9/5)*celsius + 32
print("Fahrenheit ",fahrenheit)
#input fahrenheit
fahrenheit = 37

celsius = (5/9)*(fahrenheit - 32)
print("Celsius ",celsius)