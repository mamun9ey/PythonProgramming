x=-13
result=x/2

print(result)
print(str(result))
print(type(result))

