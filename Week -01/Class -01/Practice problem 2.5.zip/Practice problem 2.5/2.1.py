x =25.69
print(int(x))