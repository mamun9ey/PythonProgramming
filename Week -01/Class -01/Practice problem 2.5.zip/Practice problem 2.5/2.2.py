x=20
result1=x/2
result2=x/3
print(result1,result2)
print(type(result1))
print(type(result2))