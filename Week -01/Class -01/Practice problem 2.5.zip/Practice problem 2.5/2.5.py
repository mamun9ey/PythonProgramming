n1,n2 ="20","10"
print(n1+n2)