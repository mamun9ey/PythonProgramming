x=y=z=25
print(x,y,z)