firstName="Abdullah """
middleName="Al """
lastName="Mamun """
print(firstName + middleName + lastName)