University,Id,Location="DUET",194011,"Gazipur" 
print(University,Id,Location) 