num = int(input())
for i in range(1, 11):
   print(num, 'x', i, '=', num*i)