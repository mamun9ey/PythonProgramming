number=12458789
last_digit = int(str(number)[-1])
print(last_digit)