print("Enter the range of number:")

n=int(input())
sum=0
i=2
while(i<=n):
    sum+=i
    i+=2
print("The sum of the series = ",sum)