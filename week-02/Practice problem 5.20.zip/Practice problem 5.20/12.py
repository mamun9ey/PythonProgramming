for i in range(97,123):
    print(chr(i), end=" ")
