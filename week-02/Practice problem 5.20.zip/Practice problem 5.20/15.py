num = 12345645
print(len(str(num)))