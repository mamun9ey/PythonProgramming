number = int(input("Please Enter any Number: "))
i = number
while ( i >= 1):
    print (i, end = '  ')
    i = i - 1