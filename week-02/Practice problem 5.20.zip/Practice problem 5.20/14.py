num=12587934
first = int(str(num)[0])

print(first)