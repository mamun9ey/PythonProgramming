#Write a program to check whether a number is even or odd
num=int(input())
if num%2==0:
    print(num,"is even number.")
else:
    print(num,"is odd number.")