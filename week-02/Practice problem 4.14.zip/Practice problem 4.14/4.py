#Write a Program to check whether a number is divisible by 5 and 11  or not
x=int(input())
if x/5 and x/11:
    print("It's Divisible Number")
else:
    print("It's not Divisible")