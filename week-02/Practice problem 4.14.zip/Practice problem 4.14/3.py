#Write a program to check whether a number is negative ,postive or zero 
x=int(input())
if(x<0):
    print("Number is negative")
elif(x>0):
    print("Number is positive")
else:
    print("Number is Zero")
    