#Write a Program to find maximum between three numbers
x,y,z=10,20,30
if(x<y and y>z):
    print("Maximum number is:",y)
elif(x>y and y>z):
    print("Maximum number is:",x)
else:
    print("Maximum number is ",z)
    