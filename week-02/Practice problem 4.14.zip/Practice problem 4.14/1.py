#Write a program to find maximum between two numbers 
x=10;
y=20;
if(x<y):
    print("maximum number is:",y)

else:
    print("maximum number is :",x)
