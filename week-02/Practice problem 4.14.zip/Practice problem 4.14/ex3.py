x=int(input())
y=int(input())
if x<y:
    print("FIRST")
elif x==y:
    print("ANY")
else:
    print("SECOND")