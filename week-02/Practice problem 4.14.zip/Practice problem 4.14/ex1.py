x=int(input())
y=int(input())
if x<y:
    print("Minimum number of buttton presses:",y-x)
elif x>y:
    
    print("Minimum number of button presses:",x-y)
else:
    print("Don'st exisited")