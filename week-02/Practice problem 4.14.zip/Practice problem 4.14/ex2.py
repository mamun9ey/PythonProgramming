x=int(input())
y=int(input())
if x==y:
    print("YES")
else:
    print("NO")