N=int(input())
print(N)