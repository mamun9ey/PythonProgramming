for i in range(int(input())):
    s = input()
    print(int(s[0]) + int(s[len(s) - 1]))